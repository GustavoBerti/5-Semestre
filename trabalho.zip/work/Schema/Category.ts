import mongoose, { Document, Schema } from 'mongoose';

interface ICategory extends Document {
  ID: number;
  nome: string;
  cor: string;
}

const CategorySchema = new Schema<ICategory>({
  ID: Number,
  nome: String,
  cor: String
});

export default mongoose.model<ICategory>('Category', CategorySchema);
