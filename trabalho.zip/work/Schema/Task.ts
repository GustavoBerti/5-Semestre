import mongoose, { Document, Schema } from 'mongoose';

interface ITask extends Document {
  ID: number;
  título: string;
  descrição: string;
  dataDeCriação: Date;
  dataDeConclusão: Date | null;
  tipo: string;
  categoria: { type: Schema.Types.ObjectId, ref: 'Category' } | null;
  status: 'pendente' | 'em andamento' | 'concluída';
  usuárioAssociado: { type: Schema.Types.ObjectId, ref: 'User' };
}

const TaskSchema = new Schema<ITask>({
  ID: Number,
  título: String,
  descrição: String,
  dataDeCriação: Date,
  dataDeConclusão: Date,
  tipo: String,
  categoria: { type: Schema.Types.ObjectId, ref: 'Category' },
  status: { type: String, enum: ['pendente', 'em andamento', 'concluída'] },
  usuárioAssociado: { type: Schema.Types.ObjectId, ref: 'User' }
});

export default mongoose.model<ITask>('Task', TaskSchema);
