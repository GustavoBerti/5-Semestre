import mongoose, { Document, Schema } from 'mongoose';

interface IUser extends Document {
  nomeDeUsuario: string;
  peso: number;
  senha: string;
  email: string;
}

const UserSchema = new Schema<IUser>({
  nomeDeUsuario: String,
  peso: Number,
  senha: String,
  email: String
});

export default mongoose.model<IUser>('User', UserSchema);
