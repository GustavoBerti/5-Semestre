import express, { Request, Response } from 'express';
import User from '../Schema/User';

export default class UserController {
  static create: RequestHandler<{}, any, any, ParsedQs, Record<string, any>>;
  async create(req: Request, res: Response): Promise<Response> {
    const { nomeDeUsuario, peso, senha, email } = req.body;
    const user = new User({ nomeDeUsuario, peso, senha, email });
    await user.save();
    return res.status(201).json(user);
  }

}
