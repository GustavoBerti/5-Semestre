import { Request, Response } from 'express';
import Category from '../Schema/Category';

export default class CategoryController {
  static create(arg0: string, create: any) {
      throw new Error('Method not implemented.');
  }
  async create(req: Request, res: Response): Promise<Response> {
    const { ID, nome, cor } = req.body;
    const category = new Category({ ID, nome, cor });
    await category.save();
    return res.status(201).json(category);
  }

}