import { Request, Response } from 'express';
import Task from '../Schema/Task';

export default class TaskController {
  static create(arg0: string, create: any) {
      throw new Error('Method not implemented.');
  }
  async create(req: Request, res: Response): Promise<Response> {
    const { ID, título, descrição, dataDeCriação, dataDeConclusão, tipo, categoria, status, usuárioAssociado } = req.body;
    const task = new Task({ ID, título, descrição, dataDeCriação, dataDeConclusão, tipo, categoria, status, usuárioAssociado });
    await task.save();
    return res.status(201).json(task);
  }

}
